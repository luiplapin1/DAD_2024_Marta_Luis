package lab1;

import java.util.Calendar;
import java.util.Objects;

public class Actuador {
	
	
	private Integer idDevise;
	private Integer idSensor;
	private long timestamp;  //Calendar.getInstance().getTimeInMillis()
	private boolean activo;
	private boolean encendido;
	
	
	public Actuador() {
		super();	
		timestamp=Calendar.getInstance().getTimeInMillis();
		activo=false;
	}
	


	public Actuador(Integer id, long timestamp, boolean activo, boolean encendido, Integer idDevise, Integer idSensor) {
		super();
		this.idDevise = idDevise;
		this.idSensor = idSensor;
		this.timestamp = timestamp;
		this.activo = activo;
		this.encendido = encendido;
	}




	public Integer getIdDevise() {
		return idDevise;
	}




	public void setIdDevise(Integer idDevise) {
		this.idDevise = idDevise;
	}




	public Integer getIdSensor() {
		return idSensor;
	}




	public void setIdSensor(Integer idSensor) {
		this.idSensor = idSensor;
	}




	public long getTimestamp() {
		return timestamp;
	}




	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}




	public boolean isActivo() {
		return activo;
	}




	public void setActivo(boolean activo) {
		this.activo = activo;
	}




	public boolean isEncendido() {
		return encendido;
	}




	public void setEncendido(boolean encendido) {
		this.encendido = encendido;
	}




	@Override
	public String toString() {
		return "Actuador [idDevise=" + idDevise + ", idSensor=" + idSensor + ", timestamp=" + timestamp + ", activo="
				+ activo + ", encendido=" + encendido + "]";
	}




	@Override
	public int hashCode() {
		return Objects.hash(activo, encendido, idDevise, idSensor, timestamp);
	}




	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Actuador other = (Actuador) obj;
		return activo == other.activo && encendido == other.encendido && Objects.equals(idDevise, other.idDevise)
				&& Objects.equals(idSensor, other.idSensor) && timestamp == other.timestamp;
	}
	
	
	


}