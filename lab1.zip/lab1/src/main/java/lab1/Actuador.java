package lab1;

import java.util.Calendar;
import java.util.Objects;

public class Actuador {
	
	
	private Integer id;
	private long timestamp;  //Calendar.getInstance().getTimeInMillis()
	private boolean activo;
	
	
	public Actuador() {
		super();	
		timestamp=Calendar.getInstance().getTimeInMillis();
		activo=false;
	}
	
	


	public Actuador(Integer id, long timestamp, boolean activo) {
		super();
		this.id = id;
		this.timestamp = timestamp;
		this.activo = activo;
	}




	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public long getTimestamp() {
		return timestamp;
	}


	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}


	public boolean isActivo() {
		return activo;
	}


	public void setActivo(boolean activo) {
		this.activo = activo;
	}


	@Override
	public String toString() {
		return "Actuador [id=" + id + ", timestamp=" + timestamp + ", activo=" + activo + "]";
	}


	@Override
	public int hashCode() {
		return Objects.hash(activo, id, timestamp);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Actuador other = (Actuador) obj;
		return activo == other.activo && Objects.equals(id, other.id) && timestamp == other.timestamp;
	}
	
	
	
	
}
