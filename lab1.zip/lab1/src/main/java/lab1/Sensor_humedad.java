package lab1;


import java.util.Calendar;
import java.util.Objects;

public class Sensor_humedad {
	
	private Integer id;
	private long timestamp;  //Calendar.getInstance().getTimeInMillis()
	private Float humedad;
	private Float temperatura;
	
	public Sensor_humedad() {
		super();	
		timestamp=Calendar.getInstance().getTimeInMillis();
		humedad=0.0f;
		temperatura= 0.0f;
	}

	
	public Sensor_humedad(Integer id, long timestamp, Float humedad, Float temperatura) {
		super();
		this.id = id;
		this.timestamp = timestamp;
		this.humedad = humedad;
		this.temperatura = temperatura;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public long getTimestamp() {
		return timestamp;
	}


	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}


	public Float getHumedad() {
		return humedad;
	}


	public void setHumedad(Float humedad) {
		this.humedad = humedad;
	}


	public Float getTemperatura() {
		return temperatura;
	}


	public void setTemperatura(Float temperatura) {
		this.temperatura = temperatura;
	}


	@Override
	public String toString() {
		return "Sensor_humedad [id=" + id + ", timestamp=" + timestamp + ", humedad=" + humedad + ", temperatura="
				+ temperatura + "]";
	}


	@Override
	public int hashCode() {
		return Objects.hash(humedad, id, temperatura, timestamp);
	}

	
	

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sensor_humedad other = (Sensor_humedad) obj;
		return Objects.equals(humedad, other.humedad) && Objects.equals(id, other.id)
				&& Objects.equals(temperatura, other.temperatura) && timestamp == other.timestamp;
	}
	
	
	
	
	
}
