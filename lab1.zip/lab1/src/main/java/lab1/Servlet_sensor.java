package lab1;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Servlet_sensor extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    
    // Simulamos una instancia de Sensor_humedad
    private Sensor_humedad sensor = new Sensor_humedad(1, System.currentTimeMillis(), 25.5f, 50.0f);

    private Map<Integer, Sensor_humedad> datosSensor; //mapa que relaciona el id con los datos del sensor
    
    public void init() throws ServletException{
		datosSensor = new HashMap<Integer, Sensor_humedad>();
		datosSensor.put(0, sensor); // inicializo datos Sensor
		super.init();
	}
    
    @SuppressWarnings("unlikely-arg-type")
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException{
    	//obtengo el id que usare luego
    	String id = req.getParameter("id");
    	
    	
    	if(datosSensor.containsKey(id)) {
    		// tengo que devolver un objeto json relacionado con el id que que hemos obtenido antes
    		Gson gson = new Gson();
    		resp.getWriter().println(gson.toJson(datosSensor.get(id)));  // esta función no devuelve nada pq es void simplemente lo imprime
    	} else {
    		//si da error no tiene sentido que devuelva nada, por eso devuelve un objeto Json pero vacío
    		Gson gson2 = new Gson();
    		resp.getWriter().println(gson2.toJson(""));
    	} 
    }
   

	// el doPost esta bien de esta manera
    protected void doPost (HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException {
    	BufferedReader reader = req.getReader();
    	
    	Gson gson = new Gson();
    	Sensor_humedad s1 = gson.fromJson(reader, Sensor_humedad.class);
    	
    	if(!s1.getHumedad().equals("") && !s1.getTemperatura().equals("")){
    		datosSensor.put(s1.getId(),s1); // le pasamos s1 para que me lea los atributos y los meta como 'valor' en el diccionario
    	}
    	
    }
    
    // el response esta bien asi
    protected void response(HttpServletResponse response, Object msg) throws ServletException, IOException {
        response.setContentType("text/html");
        
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Valores de Temperatura y Humedad</h1>");
        out.println("<p>Tipo de sensor: Humedad y temperatura</p>");
        out.println("<p>Temperatura: " + sensor.getTemperatura() + "</p>");
        out.println("<p>Humedad: " + sensor.getHumedad() + "</p>");
        out.println("</body></html>");
    }
    
    

  

}
