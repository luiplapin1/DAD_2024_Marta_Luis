package lab1;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Servlet_sensor extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    
    // Simulamos una instancia de Sensor_humedad
    private Sensor_humedad sensor = new Sensor_humedad(1, System.currentTimeMillis(), 25.5f, 50.0f);

    private Map<Integer, Sensor_humedad> datosSensor; //Map que relaciona usuario y contraseña
    
    public void init() throws ServletException{
		datosSensor = new HashMap<Integer, Sensor_humedad>();
		super.init();
	}
    
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException{
    	String humedad = req.getParameter("humedad");
    	String temperatura = req.getParameter("temperatura");
    	
    	// la parte de verificar la contraseña no se hacerla 
    }
    
    protected void doPost (HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	BufferedReader reader = req.getReader();
    	
    	Gson gson = new Gson();
    	Actuador act = gson.fromJson(reader, Actuador.class);
    	
    	
    }
    
    protected void response(HttpServletRequest request, HttpServletResponse response, String msg) throws ServletException, IOException {
        response.setContentType("text/html");
        
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Valores de Temperatura y Humedad</h1>");
        out.println("<p>Temperatura: " + sensor.getTemperatura() + "</p>");
        out.println("<p>Humedad: " + sensor.getHumedad() + "</p>");
        out.println("</body></html>");
    }
    
    

  

}
