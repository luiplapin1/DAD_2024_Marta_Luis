package Sensor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;



public class SensorEntityListWrapper {
	
	private List<Sensor_humedad_Entity> sensor_humedad_List;
	
	public SensorEntityListWrapper(){
		super();
	}
	
	public SensorEntityListWrapper(Collection<Sensor_humedad_Entity> sensor_humedad_List) {
		super();
		this.sensor_humedad_List = new ArrayList<Sensor_humedad_Entity>(sensor_humedad_List);
	}
	
	public SensorEntityListWrapper(List<Sensor_humedad_Entity> sensor_humedad_List) {
		super();
		this.sensor_humedad_List = new ArrayList<Sensor_humedad_Entity>(sensor_humedad_List);
	}

	public List<Sensor_humedad_Entity> getSensor_humedad_List() {
		return sensor_humedad_List;
	}

	public void setSensor_humedad_List(List<Sensor_humedad_Entity> sensor_humedad_List) {
		this.sensor_humedad_List = sensor_humedad_List;
	}

	@Override
	// calcula el hascode si el objeto no es nulo
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((sensor_humedad_List == null) ? 0 : sensor_humedad_List.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SensorEntityListWrapper other = (SensorEntityListWrapper) obj;
		return Objects.equals(sensor_humedad_List, other.sensor_humedad_List);
	}

	@Override
	public String toString() {
		return "SensorEntityListWrapper [sensor_humedad_List=" + sensor_humedad_List + "]";
	}

	
	
}
