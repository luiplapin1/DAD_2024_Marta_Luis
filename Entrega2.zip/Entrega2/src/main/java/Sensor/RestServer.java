package Sensor;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import io.vertx.core.Promise;
import io.vertx.core.AbstractVerticle;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;



public class RestServer extends AbstractVerticle{
	
	// creo el mapa de los datos
	private Map<Integer, Sensor_humedad_Entity> datos_sensor = new HashMap<Integer, Sensor_humedad_Entity>();
	private Gson gson;
	
	public void start(Promise<Void> startFuture) {
		createSomeData(25);
		
		// se crea el objeto json con la idea de serializar el objeto
		gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		
		// Defining the router object
		Router router = Router.router(vertx);
		vertx.createHttpServer().requestHandler(router::handle).listen(8080, result -> {
		if (result.succeeded()) {
			startFuture.complete();
		} else {
			startFuture.fail(result.cause());
		}
	});

	
	/* 
	 Para el entregable 2 esto es lo peimero que tengo que hacer obtener todos los sensores de una placa con ID --> petición get
		- /placa/placaId/:sensor  
	 Obtener toda la información de un sensor que pertenece a una placa --> petición get --> 2 maneras
		- /placa/placaId/sensor/:sensorId   Se el identificador del sensor y el identificadaor de la placa. Es mejor, mas info y mas rapido
		- /sensor/placaId/:sensorId    Solamente se el identificador del sensor
	 */
		
		router.route("/api/datos_sensor/all").handler(this::getAll); //método creado abajo --> OjO NO dos gets o dos posts con el mismo nombre de ruta
		

	
	}
	
	// devuelve todos los sensores
		@SuppressWarnings("unused")
		private void getAll(RoutingContext routingContext) { // cualquier metodo que tenga get tiene que tener por algún parámetro de tipo RoutingContext 
			routingContext.response().putHeader("content-type", "application/json; charset=utf-8").setStatusCode(200) //devuelve datos al cliete
			// putHeader --> le decimos al cliente que le vamos a mandar algo de tipo json
			// fijo el setStatusCode para decirle al cliente si ha ido todo bien o no
					.end(gson.toJson(new SensorEntityListWrapper(datos_sensor.values())));
		}
		
		// devuelve todo con todos los parámetros
		private void getAllWithParams(RoutingContext routingContext) {
			final String id = routingContext.queryParams().contains("id") ? routingContext.queryParam("id").get(0) : null;
			final String timestamp = routingContext.queryParams().contains("timestamp") ? routingContext.queryParam("timestamp").get(0) : null;
			final String humedad = routingContext.queryParams().contains("humedad") ? routingContext.queryParam("humedad").get(0) : null;
			final String temperatura = routingContext.queryParams().contains("temperatura") ? routingContext.queryParam("temperatura").get(0) : null;
			
			routingContext.response().putHeader("content-type", "application/json; charset=utf-8").setStatusCode(200)
					.end(gson.toJson(new SensorEntityListWrapper(datos_sensor.values().stream().filter(elem -> {
						boolean res = true;
						res = res && id != null ? elem.getId().equals(id) : true;
						res = res && timestamp != null ? elem.getTimestamp().equals(timestamp) : true;
						res = res && humedad != null ? elem.getHumedad().equals(humedad) : true;
						res = res && temperatura != null ? elem.getTemperatura().equals(temperatura) : true;
						return res;
					}).collect(Collectors.toList()))));
		}

	
	
	// Esta función generará number entidades de sensor de humedad con valores aleatorios para la humedad y la temperatura, así como un identificador único y un timestamp basado en el tiempo actual.
	// meto en la clase SensorEntityListWrapper (lista de entidades de sensores) las nuevas entidades que se van creando de forma aleatoria
	private void createSomeData(int number) {
	    Random rnd = new Random();
	    IntStream.range(0, number).forEach(elem -> {
	        int id = rnd.nextInt();
	        long timestamp = Calendar.getInstance().getTimeInMillis() + id;
	        float humedad = rnd.nextFloat() * 100; // Genera un valor aleatorio entre 0 y 100 para la humedad
	        float temperatura = rnd.nextFloat() * 50; // Genera un valor aleatorio entre 0 y 50 para la temperatura
	        datos_sensor.put(id, new Sensor_humedad_Entity(id, timestamp, humedad, temperatura));
	    });
	}
	
	
	
	
}
